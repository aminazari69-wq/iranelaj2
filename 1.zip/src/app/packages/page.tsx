import { getTranslations, getLocale } from 'next-intl/server'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { Check, Star, Clock, Plane, Hotel, Stethoscope } from 'lucide-react'
import prisma from '@/lib/prisma'

export const metadata = {
  title: 'Treatment Packages',
  description: 'Explore our comprehensive medical treatment packages.',
}

export default async function PackagesPage() {
  const t = await getTranslations()
  const locale = await getLocale()

  let packages = await prisma.package.findMany({
    where: { isActive: true },
    orderBy: { createdAt: 'desc' },
  })

  if (packages.length === 0) {
    packages = [
      { id: '1', nameAr: 'باقة تجميل الأنف الشاملة', nameFa: 'پکیج کامل رینوپلاستی', nameEn: 'Complete Rhinoplasty Package', descAr: 'تشمل الجراحة والإقامة والرعاية اللاحقة', descFa: 'شامل جراحی، اقامت و مراقبت‌های بعدی', descEn: 'Includes surgery, accommodation and aftercare', type: 'treatment', price: 3500, duration: '10 days', includes: '["Surgery","Hospital stay","Airport transfer","Translation","Follow-up"]', image: null, specialty: 'cosmetic', isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '2', nameAr: 'باقة زراعة الأسنان', nameFa: 'پکیج ایمپلنت دندان', nameEn: 'Dental Implant Package', descAr: 'زراعة أسنان عالية الجودة', descFa: 'ایمپلنت دندان با کیفیت بالا', descEn: 'High-quality dental implants', type: 'treatment', price: 1200, duration: '7 days', includes: '["Implants","X-rays","Follow-up","Translation"]', image: null, specialty: 'dentistry', isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '3', nameAr: 'باقة عملية الليزك', nameFa: 'پکیج عمل لیزیک', nameEn: 'LASIK Surgery Package', descAr: 'تصحيح النظر بالليزر', descFa: 'اصلاح بینایی با لیزر', descEn: 'Laser vision correction', type: 'treatment', price: 1500, duration: '5 days', includes: '["Surgery","Eye drops","Check-ups","Glasses"]', image: null, specialty: 'ophthalmology', isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '4', nameAr: 'باقة السفر والإقامة', nameFa: 'پکیج سفر و اقامت', nameEn: 'Travel & Stay Package', descAr: 'تشمل الفندق والمواصلات', descFa: 'شامل هتل و حمل و نقل', descEn: 'Includes hotel and transportation', type: 'travel_accommodation', price: 800, duration: '7 days', includes: '["4-star hotel","Airport transfer","City tour","Translation"]', image: null, specialty: null, isActive: true, createdAt: new Date(), updatedAt: new Date() },
    ] as typeof packages
  }

  const getName = (p: typeof packages[0]) => locale === 'ar' ? p.nameAr : locale === 'fa' ? p.nameFa : p.nameEn
  const getDesc = (p: typeof packages[0]) => locale === 'ar' ? p.descAr : locale === 'fa' ? p.descFa : p.descEn

  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {t('packages.title')}
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {t('packages.subtitle')}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {packages.map((pkg) => (
            <Card key={pkg.id} className="card-hover overflow-hidden">
              <CardContent className="p-0">
                <div className="h-48 bg-gradient-to-br from-[#0099A8] to-[#026D73] flex items-center justify-center">
                  {pkg.type === 'travel_accommodation' ? (
                    <Plane className="w-16 h-16 text-white/50" />
                  ) : (
                    <Stethoscope className="w-16 h-16 text-white/50" />
                  )}
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs bg-[#0099A8]/10 text-[#0099A8] px-2 py-1 rounded-full capitalize">
                      {pkg.specialty || 'Travel'}
                    </span>
                    {pkg.duration && (
                      <span className="text-xs text-gray-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {pkg.duration}
                      </span>
                    )}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{getName(pkg)}</h3>
                  <p className="text-gray-600 text-sm mb-4">{getDesc(pkg)}</p>
                  
                  {pkg.includes && (
                    <div className="mb-4">
                      <h4 className="text-sm font-semibold mb-2">{t('packages.includes')}:</h4>
                      <ul className="space-y-1">
                        {JSON.parse(pkg.includes).slice(0, 4).map((item: string, i: number) => (
                          <li key={i} className="flex items-center gap-2 text-sm text-gray-600">
                            <Check className="w-4 h-4 text-green-500" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-4 border-t">
                    <div>
                      <span className="text-xs text-gray-500">{t('packages.from')}</span>
                      <div className="text-2xl font-bold text-[#0099A8]">${pkg.price}</div>
                    </div>
                    <Link href="/request">
                      <Button>{t('packages.book')}</Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
