import { getTranslations, getLocale } from 'next-intl/server'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { MapPin, Star, Building2, Phone } from 'lucide-react'
import prisma from '@/lib/prisma'
import Link from 'next/link'

export const metadata = {
  title: 'Partner Hospitals',
  description: 'Explore our partner hospitals with international accreditation.',
}

export default async function HospitalsPage() {
  const t = await getTranslations()
  const locale = await getLocale()

  let hospitals = await prisma.hospital.findMany({
    where: { isActive: true },
    orderBy: { rating: 'desc' },
  })

  if (hospitals.length === 0) {
    hospitals = [
      { id: '1', nameAr: 'مستشفى طهران الطبي', nameFa: 'بیمارستان پزشکی تهران', nameEn: 'Tehran Medical Center', descAr: 'مستشفى متعدد التخصصات معتمد دولياً', descFa: 'بیمارستان چند تخصصی با اعتبار بین‌المللی', descEn: 'Multi-specialty hospital with international accreditation', address: 'Tehran, Iran', city: 'Tehran', image: null, logo: null, specialties: '["cosmetic","cardiology","orthopedics"]', rating: 4.9, isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '2', nameAr: 'مستشفى القلب', nameFa: 'بیمارستان قلب', nameEn: 'Heart Hospital', descAr: 'مركز متخصص في أمراض القلب', descFa: 'مرکز تخصصی قلب و عروق', descEn: 'Specialized cardiac care center', address: 'Tehran, Iran', city: 'Tehran', image: null, logo: null, specialties: '["cardiology"]', rating: 4.8, isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '3', nameAr: 'عيادة الأسنان الدولية', nameFa: 'کلینیک بین‌المللی دندانپزشکی', nameEn: 'International Dental Clinic', descAr: 'مركز طب الأسنان التجميلي', descFa: 'مرکز دندانپزشکی زیبایی', descEn: 'Cosmetic dentistry center', address: 'Shiraz, Iran', city: 'Shiraz', image: null, logo: null, specialties: '["dentistry"]', rating: 4.9, isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '4', nameAr: 'معهد العيون', nameFa: 'انستیتو چشم', nameEn: 'Eye Institute', descAr: 'مركز جراحة العيون المتقدم', descFa: 'مرکز پیشرفته جراحی چشم', descEn: 'Advanced eye surgery center', address: 'Mashhad, Iran', city: 'Mashhad', image: null, logo: null, specialties: '["ophthalmology"]', rating: 4.7, isActive: true, createdAt: new Date(), updatedAt: new Date() },
    ] as typeof hospitals
  }

  const getName = (h: typeof hospitals[0]) => locale === 'ar' ? h.nameAr : locale === 'fa' ? h.nameFa : h.nameEn
  const getDesc = (h: typeof hospitals[0]) => locale === 'ar' ? h.descAr : locale === 'fa' ? h.descFa : h.descEn

  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {t('hospitals.title')}
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {t('hospitals.subtitle')}
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {hospitals.map((hospital) => (
            <Card key={hospital.id} className="card-hover overflow-hidden">
              <CardContent className="p-0 flex flex-col md:flex-row">
                <div className="w-full md:w-1/3 h-48 md:h-auto bg-gradient-to-br from-[#0099A8] to-[#026D73] flex items-center justify-center">
                  {hospital.image ? (
                    <img src={hospital.image} alt={getName(hospital)} className="w-full h-full object-cover" />
                  ) : (
                    <Building2 className="w-16 h-16 text-white/50" />
                  )}
                </div>
                <div className="p-6 flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-xl font-bold text-gray-900">{getName(hospital)}</h3>
                    <div className="flex items-center gap-1 text-sm">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span>{hospital.rating}</span>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm mb-4">{getDesc(hospital)}</p>
                  
                  {hospital.city && (
                    <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                      <MapPin className="w-4 h-4" />
                      <span>{hospital.city}, Iran</span>
                    </div>
                  )}

                  {hospital.specialties && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {JSON.parse(hospital.specialties).slice(0, 3).map((spec: string, i: number) => (
                        <span key={i} className="text-xs bg-[#0099A8]/10 text-[#0099A8] px-2 py-1 rounded-full capitalize">
                          {spec}
                        </span>
                      ))}
                    </div>
                  )}

                  <Link href="/request">
                    <Button variant="outline" size="sm">{t('hospitals.viewDetails')}</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
