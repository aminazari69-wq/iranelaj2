"use client"

import { useState } from 'react'
import { useTranslations } from 'next-intl'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Phone, Mail, MapPin, Clock, MessageCircle } from 'lucide-react'

export default function ContactPage() {
  const t = useTranslations()
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setLoading(true)
    
    const formData = new FormData(e.currentTarget)
    
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.get('name'),
          email: formData.get('email'),
          phone: formData.get('phone'),
          subject: formData.get('subject'),
          message: formData.get('message'),
        }),
      })
      
      if (res.ok) {
        setSuccess(true)
        e.currentTarget.reset()
      }
    } catch (error) {
      console.error(error)
    }
    
    setLoading(false)
  }

  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {t('contact.title')}
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {t('contact.subtitle')}
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Contact Info */}
          <div className="lg:col-span-1 space-y-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-[#0099A8]/10 rounded-full flex items-center justify-center">
                    <Phone className="w-6 h-6 text-[#0099A8]" />
                  </div>
                  <div>
                    <h3 className="font-semibold">{t('contact.phone')}</h3>
                    <a href="tel:+989120995507" className="text-[#0099A8]">+98 912 099 5507</a>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-[#0099A8]/10 rounded-full flex items-center justify-center">
                    <Mail className="w-6 h-6 text-[#0099A8]" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Email</h3>
                    <a href="mailto:info@iranelaj.com" className="text-[#0099A8]">info@iranelaj.com</a>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-[#0099A8]/10 rounded-full flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-[#0099A8]" />
                  </div>
                  <div>
                    <h3 className="font-semibold">{t('contact.address')}</h3>
                    <p className="text-gray-600 text-sm">Tehran, Iran</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-[#0099A8]/10 rounded-full flex items-center justify-center">
                    <Clock className="w-6 h-6 text-[#0099A8]" />
                  </div>
                  <div>
                    <h3 className="font-semibold">{t('contact.workingHours')}</h3>
                    <p className="text-gray-600 text-sm">24/7</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* WhatsApp Button */}
            <a
              href="https://wa.me/989120995507"
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <Button variant="whatsapp" size="lg" className="w-full">
                <MessageCircle className="w-5 h-5 me-2" />
                WhatsApp
              </Button>
            </a>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="p-6">
                {success ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-100 flex items-center justify-center">
                      <svg className="w-8 h-8 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{t('common.success')}</h3>
                    <p className="text-gray-600">{t('request.successMessage')}</p>
                    <Button onClick={() => setSuccess(false)} className="mt-4">
                      {t('contact.send')}
                    </Button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">{t('contact.name')} *</Label>
                        <Input id="name" name="name" required className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="phone">{t('contact.phone')}</Label>
                        <Input id="phone" name="phone" type="tel" className="mt-1" />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" name="email" type="email" className="mt-1" />
                    </div>

                    <div>
                      <Label htmlFor="subject">{t('contact.subject')}</Label>
                      <Input id="subject" name="subject" className="mt-1" />
                    </div>

                    <div>
                      <Label htmlFor="message">{t('contact.message')} *</Label>
                      <Textarea id="message" name="message" required rows={5} className="mt-1" />
                    </div>

                    <Button type="submit" size="lg" className="w-full" disabled={loading}>
                      {loading ? t('common.loading') : t('contact.send')}
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
