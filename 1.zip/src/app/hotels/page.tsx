import { getTranslations, getLocale } from 'next-intl/server'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Star, MapPin, Wifi, Coffee, Car, Dumbbell } from 'lucide-react'
import prisma from '@/lib/prisma'
import Link from 'next/link'

export const metadata = {
  title: 'Partner Hotels',
  description: 'Find comfortable accommodation near our partner hospitals.',
}

export default async function HotelsPage() {
  const t = await getTranslations()
  const locale = await getLocale()

  let hotels = await prisma.hotel.findMany({
    where: { isActive: true },
    orderBy: { stars: 'desc' },
  })

  if (hotels.length === 0) {
    hotels = [
      { id: '1', nameAr: 'فندق اسبيناس بالاس', nameFa: 'هتل اسپیناس پالاس', nameEn: 'Espinas Palace Hotel', descAr: 'فندق 5 نجوم فاخر في قلب طهران', descFa: 'هتل لوکس 5 ستاره در قلب تهران', descEn: 'Luxury 5-star hotel in the heart of Tehran', address: 'Tehran, Vali-e-Asr', city: 'Tehran', stars: 5, priceRange: '$150-300', amenities: '["wifi","pool","gym","restaurant","spa"]', image: null, images: null, isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '2', nameAr: 'فندق بارسيان آزادي', nameFa: 'هتل پارسیان آزادی', nameEn: 'Parsian Azadi Hotel', descAr: 'فندق تاريخي 5 نجوم', descFa: 'هتل تاریخی 5 ستاره', descEn: 'Historic 5-star hotel', address: 'Tehran, Chamran', city: 'Tehran', stars: 5, priceRange: '$120-250', amenities: '["wifi","pool","gym","restaurant"]', image: null, images: null, isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '3', nameAr: 'فندق هما', nameFa: 'هتل هما', nameEn: 'Homa Hotel', descAr: 'فندق 4 نجوم مريح', descFa: 'هتل 4 ستاره راحت', descEn: 'Comfortable 4-star hotel', address: 'Shiraz, Zand', city: 'Shiraz', stars: 4, priceRange: '$80-150', amenities: '["wifi","restaurant","parking"]', image: null, images: null, isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '4', nameAr: 'فندق كوثر', nameFa: 'هتل کوثر', nameEn: 'Kowsar Hotel', descAr: 'إقامة بأسعار معقولة', descFa: 'اقامت با قیمت مناسب', descEn: 'Affordable accommodation', address: 'Isfahan, Chahar Bagh', city: 'Isfahan', stars: 4, priceRange: '$70-120', amenities: '["wifi","restaurant"]', image: null, images: null, isActive: true, createdAt: new Date(), updatedAt: new Date() },
    ] as typeof hotels
  }

  const getName = (h: typeof hotels[0]) => locale === 'ar' ? h.nameAr : locale === 'fa' ? h.nameFa : h.nameEn
  const getDesc = (h: typeof hotels[0]) => locale === 'ar' ? h.descAr : locale === 'fa' ? h.descFa : h.descEn

  const amenityIcons: Record<string, typeof Wifi> = {
    wifi: Wifi,
    restaurant: Coffee,
    parking: Car,
    gym: Dumbbell,
  }

  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {t('nav.hotels')}
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {locale === 'ar' ? 'إقامة مريحة بالقرب من مستشفياتنا الشريكة' : locale === 'fa' ? 'اقامت راحت نزدیک بیمارستان‌های همکار ما' : 'Comfortable accommodation near our partner hospitals'}
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {hotels.map((hotel) => (
            <Card key={hotel.id} className="card-hover overflow-hidden">
              <CardContent className="p-0 flex flex-col md:flex-row">
                <div className="w-full md:w-1/3 h-48 md:h-auto bg-gradient-to-br from-[#0099A8] to-[#026D73] flex items-center justify-center">
                  <span className="text-6xl">🏨</span>
                </div>
                <div className="p-6 flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-xl font-bold text-gray-900">{getName(hotel)}</h3>
                    <div className="flex items-center gap-0.5">
                      {[...Array(hotel.stars || 4)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm mb-3">{getDesc(hotel)}</p>
                  
                  {hotel.city && (
                    <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
                      <MapPin className="w-4 h-4" />
                      <span>{hotel.city}, Iran</span>
                    </div>
                  )}

                  {hotel.amenities && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {JSON.parse(hotel.amenities).slice(0, 4).map((amenity: string, i: number) => {
                        const Icon = amenityIcons[amenity] || Wifi
                        return (
                          <span key={i} className="flex items-center gap-1 text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                            <Icon className="w-3 h-3" />
                            {amenity}
                          </span>
                        )
                      })}
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-3 border-t">
                    {hotel.priceRange && (
                      <span className="text-[#0099A8] font-semibold">{hotel.priceRange}/night</span>
                    )}
                    <Link href="/request">
                      <Button variant="outline" size="sm">{t('packages.book')}</Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
