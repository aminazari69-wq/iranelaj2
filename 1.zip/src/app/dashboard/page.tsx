"use client"

import { useEffect, useState } from 'react'
import { useTranslations } from 'next-intl'
import Link from 'next/link'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { FileText, Plus, User, Clock, CheckCircle, AlertCircle } from 'lucide-react'

interface MedicalRequest {
  id: string
  condition: string
  specialties: string
  status: string
  createdAt: string
  files: { id: string; fileName: string }[]
}

const statusColors: Record<string, 'info' | 'warning' | 'success' | 'error' | 'secondary'> = {
  new: 'info',
  under_review: 'warning',
  need_documents: 'warning',
  approved: 'success',
  rejected: 'error',
  travel_planning: 'info',
  completed: 'secondary',
}

export default function DashboardPage() {
  const t = useTranslations()
  const [requests, setRequests] = useState<MedicalRequest[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchRequests()
  }, [])

  const fetchRequests = async () => {
    try {
      const res = await fetch('/api/requests')
      if (res.ok) {
        const data = await res.json()
        setRequests(data)
      }
    } catch (error) {
      console.error(error)
    }
    setLoading(false)
  }

  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-gray-900">{t('dashboard.title')}</h1>
          <Link href="/request">
            <Button>
              <Plus className="w-4 h-4 me-2" />
              {t('dashboard.newRequest')}
            </Button>
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <FileText className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold">{requests.length}</div>
                <div className="text-sm text-gray-500">{t('dashboard.myRequests')}</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {requests.filter(r => ['new', 'under_review'].includes(r.status)).length}
                </div>
                <div className="text-sm text-gray-500">{t('status.under_review')}</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {requests.filter(r => r.status === 'approved').length}
                </div>
                <div className="text-sm text-gray-500">{t('status.approved')}</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex items-center gap-4">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <div className="text-2xl font-bold">
                  {requests.filter(r => r.status === 'travel_planning').length}
                </div>
                <div className="text-sm text-gray-500">{t('status.travel_planning')}</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Requests List */}
        <Card>
          <CardHeader>
            <CardTitle>{t('dashboard.myRequests')}</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">
                <div className="spinner mx-auto"></div>
                <p className="mt-4 text-gray-500">{t('common.loading')}</p>
              </div>
            ) : requests.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500 mb-4">{t('dashboard.noRequests')}</p>
                <Link href="/request">
                  <Button>
                    <Plus className="w-4 h-4 me-2" />
                    {t('dashboard.newRequest')}
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {requests.map((request) => (
                  <div
                    key={request.id}
                    className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant={statusColors[request.status] || 'secondary'}>
                            {t(`status.${request.status}`)}
                          </Badge>
                          <span className="text-sm text-gray-500">
                            {new Date(request.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-gray-900 font-medium mb-1">
                          {JSON.parse(request.specialties).join(', ')}
                        </p>
                        <p className="text-gray-600 text-sm line-clamp-2">
                          {request.condition}
                        </p>
                        {request.files.length > 0 && (
                          <div className="flex items-center gap-2 mt-2 text-sm text-gray-500">
                            <FileText className="w-4 h-4" />
                            {request.files.length} files
                          </div>
                        )}
                      </div>
                      <Link href={`/dashboard/requests/${request.id}`}>
                        <Button variant="outline" size="sm">
                          {t('common.view')}
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
