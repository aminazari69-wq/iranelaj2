import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { notifyAdminNewRequest } from '@/lib/whatsapp'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const userId = searchParams.get('userId')
    const status = searchParams.get('status')

    const where: Record<string, unknown> = {}
    if (userId) where.userId = userId
    if (status) where.status = status

    const requests = await prisma.medicalRequest.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            fullName: true,
            whatsapp: true,
            email: true,
          },
        },
        files: true,
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(requests)
  } catch (error) {
    console.error('Get requests error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch requests' },
      { status: 500 }
    )
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const {
      fullName,
      whatsapp,
      email,
      condition,
      specialty,
      age,
      gender,
      notes,
      files = [],
    } = body

    if (!fullName || !whatsapp || !condition || !specialty) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Find or create user
    let user = await prisma.user.findUnique({
      where: { whatsapp },
    })

    if (!user) {
      user = await prisma.user.create({
        data: {
          fullName,
          whatsapp,
          email: email || null,
        },
      })
    }

    // Create medical request
    const request = await prisma.medicalRequest.create({
      data: {
        userId: user.id,
        condition,
        specialties: JSON.stringify([specialty]),
        age: age ? parseInt(age) : null,
        gender: gender || null,
        notes: notes || null,
        status: 'new',
      },
    })

    // Create file records
    if (files.length > 0) {
      await prisma.medicalFile.createMany({
        data: files.map((filePath: string) => ({
          requestId: request.id,
          fileName: filePath.split('/').pop() || 'file',
          fileType: filePath.endsWith('.pdf') ? 'application/pdf' : 'image/jpeg',
          fileSize: 0,
          filePath,
        })),
      })
    }

    // Notify admin via WhatsApp
    const adminLink = `${process.env.NEXT_PUBLIC_SITE_URL || 'https://iranelaj.com'}/admin/requests/${request.id}`
    const fileLinks = files.map((f: string) => `${process.env.NEXT_PUBLIC_SITE_URL || 'https://iranelaj.com'}${f}`)

    const notification = await notifyAdminNewRequest({
      name: fullName,
      whatsapp,
      specialty,
      condition: condition.substring(0, 200),
      fileLinks,
      adminLink,
    })

    return NextResponse.json({
      success: true,
      request: {
        id: request.id,
        status: request.status,
      },
      whatsappLink: notification.whatsappLink,
    })
  } catch (error) {
    console.error('Create request error:', error)
    return NextResponse.json(
      { error: 'Failed to create request' },
      { status: 500 }
    )
  }
}
