// ... entire file is replaced with the new content below ...

import { getTranslations, getLocale } from 'next-intl/server'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { 
  Heart, Eye, Bone, Smile, Sparkles, Stethoscope,
  Shield, DollarSign, HeadphonesIcon, Award,
  ArrowRight, Star, MapPin, Phone
} from 'lucide-react'

export default async function HomePage() {
  const t = await getTranslations()
  const locale = await getLocale()
  const isRTL = locale === 'ar' || locale === 'fa'

  const services = [
    { icon: Sparkles, name: t('nav.cosmetic'), href: '/services/cosmetic', color: 'from-pink-500 to-rose-500' },
    { icon: Heart, name: t('nav.cardiology'), href: '/services/cardiology', color: 'from-red-500 to-pink-500' },
    { icon: Bone, name: t('nav.orthopedics'), href: '/services/orthopedics', color: 'from-blue-500 to-cyan-500' },
    { icon: Smile, name: t('nav.dentistry'), href: '/services/dentistry', color: 'from-cyan-500 to-teal-500' },
    { icon: Eye, name: t('nav.ophthalmology'), href: '/services/ophthalmology', color: 'from-purple-500 to-indigo-500' },
    { icon: Stethoscope, name: t('nav.other'), href: '/services/other', color: 'from-green-500 to-emerald-500' },
  ]

  const features = [
    { icon: Award, title: t('features.quality'), desc: t('features.qualityDesc') },
    { icon: DollarSign, title: t('features.affordable'), desc: t('features.affordableDesc') },
    { icon: HeadphonesIcon, title: t('features.support'), desc: t('features.supportDesc') },
    { icon: Shield, title: t('features.experience'), desc: t('features.experienceDesc') },
  ]

  const stats = [
    { value: '5000+', label: locale === 'ar' ? 'مريض راضٍ' : locale === 'fa' ? 'بیمار راضی' : 'Happy Patients' },
    { value: '150+', label: locale === 'ar' ? 'طبيب متخصص' : locale === 'fa' ? 'پزشک متخصص' : 'Expert Doctors' },
    { value: '50+', label: locale === 'ar' ? 'مستشفى شريك' : locale === 'fa' ? 'بیمارستان همکار' : 'Partner Hospitals' },
    { value: '98%', label: locale === 'ar' ? 'نسبة النجاح' : locale === 'fa' ? 'نرخ موفقیت' : 'Success Rate' },
  ]

  return (
    <>
      {/* Hero Section */}
      <section className="hero-gradient text-white py-16 md:py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/pattern.svg')] opacity-10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              {t('hero.title')}
            </h1>
            <p className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed">
              {t('hero.subtitle')}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/request">
                <Button size="xl" className="bg-white text-[#0099A8] hover:bg-white/90 btn-pulse w-full sm:w-auto">
                  {t('hero.cta')}
                </Button>
              </Link>
              <Link href="/services">
                <Button size="xl" variant="outline" className="border-white text-white hover:bg-white/10 w-full sm:w-auto">
                  {t('hero.learnMore')}
                </Button>
              </Link>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="#F8FDFD"/>
          </svg>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-8 bg-white shadow-sm relative -mt-1">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-[#0099A8] mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="section">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-4xl font-bold text-gray-900 mb-4">
              {t('services.title')}
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              {t('services.subtitle')}
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {services.map((service, i) => (
              <Link key={i} href={service.href}>
                <Card className="card-hover text-center h-full cursor-pointer group">
                  <CardContent className="p-6">
                    <div className={`w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br ${service.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      <service.icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="font-semibold text-gray-900 text-sm">{service.name}</h3>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link href="/services">
              <Button variant="outline" size="lg">
                {t('services.viewAll')}
                <ArrowRight className={`w-4 h-4 ${isRTL ? 'mr-2 rotate-180' : 'ml-2'}`} />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="section bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-4xl font-bold text-gray-900 mb-4">
              {t('features.title')}
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <Card key={i} className="card-hover">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[#0099A8]/10 flex items-center justify-center">
                    <feature.icon className="w-8 h-8 text-[#0099A8]" />
                  </div>
                  <h3 className="font-semibold text-lg text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600 text-sm">{feature.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 hero-gradient text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-4xl font-bold mb-4">
            {t('cta.title')}
          </h2>
          <p className="text-white/90 mb-8 max-w-2xl mx-auto">
            {t('cta.subtitle')}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="https://wa.me/989120995507" target="_blank" rel="noopener noreferrer">
              <Button size="xl" variant="whatsapp" className="w-full sm:w-auto">
                <svg className="w-5 h-5 me-2" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                {t('cta.button')}
              </Button>
            </a>
            <Link href="/request">
              <Button size="xl" className="bg-white text-[#0099A8] hover:bg-white/90 w-full sm:w-auto">
                {t('hero.cta')}
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-4xl font-bold text-gray-900 mb-4">
              {t('testimonials.title')}
            </h2>
            <p className="text-gray-600">
              {t('testimonials.subtitle')}
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { name: 'Ahmed M.', country: 'Oman', text: locale === 'ar' ? 'تجربة رائعة! الفريق الطبي كان محترفاً جداً والنتائج مذهلة.' : locale === 'fa' ? 'تجربه عالی! تیم پزشکی بسیار حرفه‌ای بود و نتایج شگفت‌انگیز.' : 'Amazing experience! The medical team was very professional and the results are incredible.' },
              { name: 'Fatima K.', country: 'UAE', text: locale === 'ar' ? 'وفرت الكثير من المال مع خدمة ممتازة. أنصح بها بشدة!' : locale === 'fa' ? 'پول زیادی صرفه‌جویی کردم با خدمات عالی. به شدت توصیه می‌کنم!' : 'Saved a lot of money with excellent service. Highly recommended!' },
              { name: 'Mohammed S.', country: 'Kuwait', text: locale === 'ar' ? 'من الترتيبات إلى العلاج، كل شيء كان مثالياً.' : locale === 'fa' ? 'از ترتیبات تا درمان، همه چیز عالی بود.' : 'From arrangements to treatment, everything was perfect.' },
            ].map((testimonial, i) => (
              <Card key={i} className="card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(5)].map((_, j) => (
                      <Star key={j} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4 italic">"{testimonial.text}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#0099A8]/10 flex items-center justify-center">
                      <span className="text-[#0099A8] font-semibold">{testimonial.name.charAt(0)}</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">{testimonial.name}</div>
                      <div className="text-sm text-gray-500 flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {testimonial.country}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="section">
        <div className="container mx-auto px-4">
          <Card className="bg-gradient-to-r from-[#0099A8] to-[#026D73] text-white overflow-hidden">
            <CardContent className="p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <h3 className="text-2xl md:text-3xl font-bold mb-2">
                  {locale === 'ar' ? 'هل لديك أسئلة؟' : locale === 'fa' ? 'سوالی دارید؟' : 'Have Questions?'}
                </h3>
                <p className="text-white/90">
                  {locale === 'ar' ? 'فريقنا جاهز لمساعدتك على مدار الساعة' : locale === 'fa' ? 'تیم ما ۲۴ ساعته آماده کمک به شماست' : 'Our team is available 24/7 to help you'}
                </p>
              </div>
              <div className="flex gap-4">
                <a href="tel:+989120995507">
                  <Button size="lg" className="bg-white text-[#0099A8] hover:bg-white/90">
                    <Phone className="w-4 h-4 me-2" />
                    {locale === 'ar' ? 'اتصل بنا' : locale === 'fa' ? 'تماس بگیرید' : 'Call Us'}
                  </Button>
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </>
  )
}

