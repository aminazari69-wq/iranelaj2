import type { Metadata } from "next";
import { Noto_Sans_Arabic, Cairo } from "next/font/google";
import { NextIntlClientProvider } from 'next-intl';
import { getLocale, getMessages } from 'next-intl/server';
import "./globals.css";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { getDirection } from "@/i18n";

const notoSansArabic = Noto_Sans_Arabic({
  variable: "--font-noto-arabic",
  subsets: ["arabic"],
  weight: ["300", "400", "500", "600", "700"],
});

const cairo = Cairo({
  variable: "--font-cairo",
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: {
    default: "IranElaj - Medical Tourism in Iran",
    template: "%s | IranElaj"
  },
  description: "Your trusted destination for medical tourism in Iran. Quality healthcare at affordable prices.",
  keywords: ["medical tourism", "Iran", "healthcare", "cosmetic surgery", "dental", "cardiology"],
  authors: [{ name: "IranElaj" }],
  openGraph: {
    type: "website",
    locale: "ar_SA",
    alternateLocale: ["fa_IR", "en_US"],
    url: "https://iranelaj.com",
    siteName: "IranElaj",
    title: "IranElaj - Medical Tourism in Iran",
    description: "Your trusted destination for medical tourism in Iran.",
  },
  twitter: {
    card: "summary_large_image",
    title: "IranElaj - Medical Tourism in Iran",
    description: "Your trusted destination for medical tourism in Iran.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const locale = await getLocale();
  const messages = await getMessages();
  const direction = getDirection(locale as 'ar' | 'fa' | 'en');

  return (
    <html lang={locale} dir={direction}>
      <head>
        <link rel="icon" href="/favicon.ico" />
        <meta name="theme-color" content="#0099A8" />
      </head>
      <body
        className={`${notoSansArabic.variable} ${cairo.variable} font-cairo antialiased bg-[#F8FDFD] text-gray-900`}
      >
        <NextIntlClientProvider messages={messages}>
          <div className="min-h-screen flex flex-col">
            <Header locale={locale} />
            <main className="flex-1">
              {children}
            </main>
            <Footer locale={locale} />
          </div>
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
