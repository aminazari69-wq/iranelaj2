"use client"

import { useState } from 'react'
import { useTranslations } from 'next-intl'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Upload, X, FileText, Image as ImageIcon, CheckCircle } from 'lucide-react'

const specialties = [
  { id: 'cosmetic', name: { ar: 'جراحة التجميل', fa: 'جراحی زیبایی', en: 'Cosmetic Surgery' } },
  { id: 'cardiology', name: { ar: 'القلب والأوعية', fa: 'قلب و عروق', en: 'Cardiology' } },
  { id: 'orthopedics', name: { ar: 'جراحة العظام', fa: 'ارتوپدی', en: 'Orthopedics' } },
  { id: 'dentistry', name: { ar: 'طب الأسنان', fa: 'دندان‌پزشکی', en: 'Dentistry' } },
  { id: 'ophthalmology', name: { ar: 'طب العيون', fa: 'چشم پزشکی', en: 'Eye Surgery' } },
  { id: 'neurology', name: { ar: 'جراحة الأعصاب', fa: 'جراحی اعصاب', en: 'Neurosurgery' } },
  { id: 'fertility', name: { ar: 'علاج العقم', fa: 'درمان ناباروری', en: 'Fertility Treatment' } },
  { id: 'bariatric', name: { ar: 'جراحة السمنة', fa: 'جراحی چاقی', en: 'Bariatric Surgery' } },
  { id: 'other', name: { ar: 'أخرى', fa: 'سایر', en: 'Other' } },
]

export default function RequestPage() {
  const t = useTranslations()
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [files, setFiles] = useState<File[]>([])
  const [formData, setFormData] = useState({
    fullName: '',
    whatsapp: '',
    email: '',
    condition: '',
    specialty: '',
    age: '',
    gender: '',
    notes: '',
  })

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files)
      setFiles(prev => [...prev, ...newFiles])
    }
  }

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Upload files first
      const uploadedFiles: string[] = []
      for (const file of files) {
        const formDataFile = new FormData()
        formDataFile.append('file', file)
        
        const uploadRes = await fetch('/api/upload', {
          method: 'POST',
          body: formDataFile,
        })
        
        if (uploadRes.ok) {
          const data = await uploadRes.json()
          uploadedFiles.push(data.filePath)
        }
      }

      // Submit request
      const res = await fetch('/api/requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          files: uploadedFiles,
        }),
      })

      if (res.ok) {
        setSuccess(true)
      }
    } catch (error) {
      console.error(error)
    }

    setLoading(false)
  }

  const locale = 'ar' // Will be dynamic

  if (success) {
    return (
      <div className="py-12">
        <div className="container mx-auto px-4 max-w-2xl">
          <Card>
            <CardContent className="p-8 text-center">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="w-10 h-10 text-green-500" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">{t('request.success')}</h2>
              <p className="text-gray-600 mb-6">{t('request.successMessage')}</p>
              <div className="flex gap-4 justify-center">
                <a href="https://wa.me/989120995507" target="_blank" rel="noopener noreferrer">
                  <Button variant="whatsapp">
                    WhatsApp
                  </Button>
                </a>
                <Button variant="outline" onClick={() => router.push('/')}>
                  {t('common.backToHome')}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="py-12">
      <div className="container mx-auto px-4 max-w-3xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('request.title')}</h1>
          <p className="text-gray-600">{t('request.successMessage')}</p>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-4 mb-8">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                step >= s ? 'bg-[#0099A8] text-white' : 'bg-gray-200 text-gray-500'
              }`}>
                {s}
              </div>
              {s < 3 && (
                <div className={`w-16 h-1 mx-2 ${step > s ? 'bg-[#0099A8]' : 'bg-gray-200'}`} />
              )}
            </div>
          ))}
        </div>

        <Card>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit}>
              {/* Step 1: Personal Info */}
              {step === 1 && (
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="fullName">{t('auth.fullName')} *</Label>
                      <Input
                        id="fullName"
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        required
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="whatsapp">{t('auth.whatsapp')} *</Label>
                      <Input
                        id="whatsapp"
                        type="tel"
                        placeholder="+968 XXXX XXXX"
                        value={formData.whatsapp}
                        onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                        required
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">{t('auth.email')}</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="mt-1"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="age">{t('request.age')}</Label>
                      <Input
                        id="age"
                        type="number"
                        value={formData.age}
                        onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label>{t('request.gender')}</Label>
                      <Select value={formData.gender} onValueChange={(v) => setFormData({ ...formData, gender: v })}>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder={t('request.gender')} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="male">{t('request.male')}</SelectItem>
                          <SelectItem value="female">{t('request.female')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button type="button" onClick={() => setStep(2)} className="w-full" disabled={!formData.fullName || !formData.whatsapp}>
                    {locale === 'ar' ? 'التالي' : locale === 'fa' ? 'بعدی' : 'Next'}
                  </Button>
                </div>
              )}

              {/* Step 2: Medical Info */}
              {step === 2 && (
                <div className="space-y-6">
                  <div>
                    <Label>{t('request.specialty')} *</Label>
                    <Select value={formData.specialty} onValueChange={(v) => setFormData({ ...formData, specialty: v })}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder={t('request.selectSpecialty')} />
                      </SelectTrigger>
                      <SelectContent>
                        {specialties.map((s) => (
                          <SelectItem key={s.id} value={s.id}>
                            {s.name[locale as keyof typeof s.name] || s.name.en}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="condition">{t('request.condition')} *</Label>
                    <Textarea
                      id="condition"
                      placeholder={t('request.conditionPlaceholder')}
                      value={formData.condition}
                      onChange={(e) => setFormData({ ...formData, condition: e.target.value })}
                      required
                      rows={5}
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="notes">{t('request.notes')}</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      rows={3}
                      className="mt-1"
                    />
                  </div>

                  <div className="flex gap-4">
                    <Button type="button" variant="outline" onClick={() => setStep(1)} className="flex-1">
                      {locale === 'ar' ? 'السابق' : locale === 'fa' ? 'قبلی' : 'Previous'}
                    </Button>
                    <Button type="button" onClick={() => setStep(3)} className="flex-1" disabled={!formData.specialty || !formData.condition}>
                      {locale === 'ar' ? 'التالي' : locale === 'fa' ? 'بعدی' : 'Next'}
                    </Button>
                  </div>
                </div>
              )}

              {/* Step 3: File Upload */}
              {step === 3 && (
                <div className="space-y-6">
                  <div>
                    <Label>{t('request.files')}</Label>
                    <p className="text-sm text-gray-500 mb-2">{t('request.filesHint')}</p>
                    
                    <label className="block">
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-[#0099A8] transition-colors">
                        <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                        <p className="text-gray-600">
                          {locale === 'ar' ? 'اسحب الملفات هنا أو انقر للتحميل' : locale === 'fa' ? 'فایل‌ها را بکشید یا کلیک کنید' : 'Drag files here or click to upload'}
                        </p>
                        <p className="text-sm text-gray-400 mt-2">PDF, JPG, PNG (max 10MB)</p>
                      </div>
                      <input
                        type="file"
                        multiple
                        accept=".pdf,.jpg,.jpeg,.png"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {files.length > 0 && (
                    <div className="space-y-2">
                      {files.map((file, i) => (
                        <div key={i} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                          {file.type.includes('image') ? (
                            <ImageIcon className="w-5 h-5 text-blue-500" />
                          ) : (
                            <FileText className="w-5 h-5 text-red-500" />
                          )}
                          <span className="flex-1 truncate text-sm">{file.name}</span>
                          <span className="text-xs text-gray-400">{(file.size / 1024).toFixed(0)} KB</span>
                          <button type="button" onClick={() => removeFile(i)} className="text-gray-400 hover:text-red-500">
                            <X className="w-5 h-5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex gap-4">
                    <Button type="button" variant="outline" onClick={() => setStep(2)} className="flex-1">
                      {locale === 'ar' ? 'السابق' : locale === 'fa' ? 'قبلی' : 'Previous'}
                    </Button>
                    <Button type="submit" className="flex-1" disabled={loading}>
                      {loading ? t('common.loading') : t('request.submit')}
                    </Button>
                  </div>
                </div>
              )}
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
