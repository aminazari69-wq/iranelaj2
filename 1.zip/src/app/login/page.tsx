"use client"

import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useTranslations } from 'next-intl'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Phone, Lock, KeyRound } from 'lucide-react'

export default function LoginPage() {
  const t = useTranslations()
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [otpSent, setOtpSent] = useState(false)
  const [formData, setFormData] = useState({
    whatsapp: '',
    password: '',
    otp: '',
  })

  const handlePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const result = await signIn('credentials', {
        whatsapp: formData.whatsapp,
        password: formData.password,
        redirect: false,
      })

      if (result?.error) {
        setError(result.error)
      } else {
        router.push('/dashboard')
      }
    } catch (err) {
      setError('Login failed')
    }

    setLoading(false)
  }

  const handleSendOtp = async () => {
    setLoading(true)
    setError('')

    try {
      const res = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ whatsapp: formData.whatsapp }),
      })

      if (res.ok) {
        setOtpSent(true)
      } else {
        const data = await res.json()
        setError(data.error || 'Failed to send OTP')
      }
    } catch (err) {
      setError('Failed to send OTP')
    }

    setLoading(false)
  }

  const handleOtpLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const result = await signIn('credentials', {
        whatsapp: formData.whatsapp,
        otp: formData.otp,
        redirect: false,
      })

      if (result?.error) {
        setError(result.error)
      } else {
        router.push('/dashboard')
      }
    } catch (err) {
      setError('Login failed')
    }

    setLoading(false)
  }

  return (
    <div className="py-12">
      <div className="container mx-auto px-4 max-w-md">
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-[#0099A8] to-[#026D73] rounded-2xl flex items-center justify-center">
              <span className="text-2xl font-bold text-white">IE</span>
            </div>
            <CardTitle className="text-2xl">{t('auth.login')}</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="password">
              <TabsList className="w-full mb-6">
                <TabsTrigger value="password" className="flex-1">
                  <Lock className="w-4 h-4 me-2" />
                  {t('auth.loginWithPassword')}
                </TabsTrigger>
                <TabsTrigger value="otp" className="flex-1">
                  <KeyRound className="w-4 h-4 me-2" />
                  {t('auth.loginWithOtp')}
                </TabsTrigger>
              </TabsList>

              {error && (
                <div className="mb-4 p-3 bg-red-50 text-red-600 rounded-lg text-sm">
                  {error}
                </div>
              )}

              <TabsContent value="password">
                <form onSubmit={handlePasswordLogin} className="space-y-4">
                  <div>
                    <Label htmlFor="whatsapp">{t('auth.whatsapp')}</Label>
                    <div className="relative mt-1">
                      <Phone className="absolute start-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        id="whatsapp"
                        type="tel"
                        placeholder="+968 XXXX XXXX"
                        value={formData.whatsapp}
                        onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                        required
                        className="ps-10"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="password">{t('auth.password')}</Label>
                    <div className="relative mt-1">
                      <Lock className="absolute start-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        id="password"
                        type="password"
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        required
                        className="ps-10"
                      />
                    </div>
                  </div>

                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? t('common.loading') : t('auth.login')}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="otp">
                <form onSubmit={handleOtpLogin} className="space-y-4">
                  <div>
                    <Label htmlFor="whatsapp-otp">{t('auth.whatsapp')}</Label>
                    <div className="relative mt-1">
                      <Phone className="absolute start-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        id="whatsapp-otp"
                        type="tel"
                        placeholder="+968 XXXX XXXX"
                        value={formData.whatsapp}
                        onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                        required
                        className="ps-10"
                        disabled={otpSent}
                      />
                    </div>
                  </div>

                  {!otpSent ? (
                    <Button type="button" onClick={handleSendOtp} className="w-full" disabled={loading || !formData.whatsapp}>
                      {loading ? t('common.loading') : t('auth.sendOtp')}
                    </Button>
                  ) : (
                    <>
                      <div>
                        <Label htmlFor="otp">{t('auth.otp')}</Label>
                        <Input
                          id="otp"
                          type="text"
                          placeholder="123456"
                          value={formData.otp}
                          onChange={(e) => setFormData({ ...formData, otp: e.target.value })}
                          required
                          className="mt-1 text-center text-2xl tracking-widest"
                          maxLength={6}
                        />
                      </div>

                      <Button type="submit" className="w-full" disabled={loading}>
                        {loading ? t('common.loading') : t('auth.login')}
                      </Button>

                      <button
                        type="button"
                        onClick={() => setOtpSent(false)}
                        className="w-full text-sm text-[#0099A8] hover:underline"
                      >
                        {t('auth.sendOtp')}
                      </button>
                    </>
                  )}
                </form>
              </TabsContent>
            </Tabs>

            <div className="mt-6 text-center text-sm text-gray-600">
              {t('auth.noAccount')}{' '}
              <Link href="/register" className="text-[#0099A8] hover:underline font-medium">
                {t('auth.register')}
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
