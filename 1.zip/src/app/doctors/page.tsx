import { getTranslations, getLocale } from 'next-intl/server'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Star, MapPin, Award } from 'lucide-react'
import prisma from '@/lib/prisma'
import Link from 'next/link'

export const metadata = {
  title: 'Our Doctors',
  description: 'Meet our team of expert doctors and specialists.',
}

export default async function DoctorsPage() {
  const t = await getTranslations()
  const locale = await getLocale()

  // Fetch doctors from database
  let doctors = await prisma.doctor.findMany({
    where: { isActive: true },
    orderBy: { rating: 'desc' },
  })

  // If no doctors in DB, use sample data
  if (doctors.length === 0) {
    doctors = [
      { id: '1', nameAr: 'د. محمد علي', nameFa: 'دکتر محمد علی', nameEn: 'Dr. Mohammad Ali', specialty: 'cosmetic', bioAr: 'جراح تجميل بخبرة 15 عاماً', bioFa: 'جراح زیبایی با 15 سال تجربه', bioEn: 'Cosmetic surgeon with 15 years experience', image: null, hospital: 'Tehran Medical Center', experience: 15, rating: 4.9, isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '2', nameAr: 'د. سارة أحمدي', nameFa: 'دکتر سارا احمدی', nameEn: 'Dr. Sara Ahmadi', specialty: 'cardiology', bioAr: 'أخصائية قلب وأوعية', bioFa: 'متخصص قلب و عروق', bioEn: 'Cardiologist specialist', image: null, hospital: 'Heart Hospital', experience: 12, rating: 4.8, isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '3', nameAr: 'د. رضا كريمي', nameFa: 'دکتر رضا کریمی', nameEn: 'Dr. Reza Karimi', specialty: 'orthopedics', bioAr: 'جراح عظام', bioFa: 'جراح ارتوپد', bioEn: 'Orthopedic surgeon', image: null, hospital: 'Orthopedic Center', experience: 18, rating: 4.9, isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '4', nameAr: 'د. مريم حسيني', nameFa: 'دکتر مریم حسینی', nameEn: 'Dr. Maryam Hosseini', specialty: 'dentistry', bioAr: 'طبيبة أسنان تجميلية', bioFa: 'دندانپزشک زیبایی', bioEn: 'Cosmetic dentist', image: null, hospital: 'Dental Clinic', experience: 10, rating: 4.7, isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '5', nameAr: 'د. علي محمدي', nameFa: 'دکتر علی محمدی', nameEn: 'Dr. Ali Mohammadi', specialty: 'ophthalmology', bioAr: 'جراح عيون', bioFa: 'جراح چشم', bioEn: 'Eye surgeon', image: null, hospital: 'Eye Institute', experience: 14, rating: 4.8, isActive: true, createdAt: new Date(), updatedAt: new Date() },
      { id: '6', nameAr: 'د. فاطمة نوري', nameFa: 'دکتر فاطمه نوری', nameEn: 'Dr. Fateme Nouri', specialty: 'neurology', bioAr: 'أخصائية أعصاب', bioFa: 'متخصص مغز و اعصاب', bioEn: 'Neurologist', image: null, hospital: 'Brain Center', experience: 16, rating: 4.9, isActive: true, createdAt: new Date(), updatedAt: new Date() },
    ] as typeof doctors
  }

  const getName = (doctor: typeof doctors[0]) => {
    return locale === 'ar' ? doctor.nameAr : locale === 'fa' ? doctor.nameFa : doctor.nameEn
  }

  const getBio = (doctor: typeof doctors[0]) => {
    return locale === 'ar' ? doctor.bioAr : locale === 'fa' ? doctor.bioFa : doctor.bioEn
  }

  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {t('doctors.title')}
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {t('doctors.subtitle')}
          </p>
        </div>

        {/* Doctors Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {doctors.map((doctor) => (
            <Card key={doctor.id} className="card-hover overflow-hidden">
              <CardContent className="p-0">
                <div className="h-48 bg-gradient-to-br from-[#0099A8] to-[#026D73] flex items-center justify-center">
                  {doctor.image ? (
                    <img src={doctor.image} alt={getName(doctor)} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center">
                      <span className="text-4xl text-white font-bold">
                        {getName(doctor).charAt(0)}
                      </span>
                    </div>
                  )}
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{getName(doctor)}</h3>
                  <p className="text-[#0099A8] text-sm mb-2 capitalize">{doctor.specialty}</p>
                  <p className="text-gray-600 text-sm mb-4">{getBio(doctor)}</p>
                  
                  <div className="flex items-center gap-4 mb-4 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Award className="w-4 h-4" />
                      <span>{doctor.experience} {t('doctors.experience')}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span>{doctor.rating}</span>
                    </div>
                  </div>

                  {doctor.hospital && (
                    <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                      <MapPin className="w-4 h-4" />
                      <span>{doctor.hospital}</span>
                    </div>
                  )}

                  <Link href="/request">
                    <Button className="w-full">{t('hero.cta')}</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
