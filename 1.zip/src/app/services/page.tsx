import { getTranslations, getLocale } from 'next-intl/server'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { 
  Heart, Eye, Bone, Smile, Sparkles, Stethoscope,
  Brain, Lung, Baby, Scissors, Syringe, Activity
} from 'lucide-react'

export const metadata = {
  title: 'Medical Services',
  description: 'Explore our comprehensive medical services including cosmetic surgery, cardiology, orthopedics, and more.',
}

export default async function ServicesPage() {
  const t = await getTranslations()
  const locale = await getLocale()

  const services = [
    { 
      icon: Sparkles, 
      id: 'cosmetic',
      name: t('nav.cosmetic'), 
      desc: locale === 'ar' ? 'جراحات تجميلية متقدمة بأحدث التقنيات' : locale === 'fa' ? 'جراحی‌های زیبایی پیشرفته با جدیدترین تکنولوژی' : 'Advanced cosmetic surgeries with the latest techniques',
      procedures: ['Rhinoplasty', 'Facelift', 'Liposuction', 'Breast Surgery', 'Tummy Tuck'],
      color: 'from-pink-500 to-rose-500' 
    },
    { 
      icon: Heart, 
      id: 'cardiology',
      name: t('nav.cardiology'), 
      desc: locale === 'ar' ? 'علاج أمراض القلب والأوعية الدموية' : locale === 'fa' ? 'درمان بیماری‌های قلب و عروق' : 'Treatment of heart and vascular diseases',
      procedures: ['Bypass Surgery', 'Angioplasty', 'Heart Valve Surgery', 'Pacemaker Implant'],
      color: 'from-red-500 to-pink-500' 
    },
    { 
      icon: Bone, 
      id: 'orthopedics',
      name: t('nav.orthopedics'), 
      desc: locale === 'ar' ? 'جراحة العظام والمفاصل' : locale === 'fa' ? 'جراحی استخوان و مفاصل' : 'Bone and joint surgery',
      procedures: ['Knee Replacement', 'Hip Replacement', 'Spine Surgery', 'Sports Medicine'],
      color: 'from-blue-500 to-cyan-500' 
    },
    { 
      icon: Smile, 
      id: 'dentistry',
      name: t('nav.dentistry'), 
      desc: locale === 'ar' ? 'طب الأسنان التجميلي والعلاجي' : locale === 'fa' ? 'دندانپزشکی زیبایی و درمانی' : 'Cosmetic and therapeutic dentistry',
      procedures: ['Dental Implants', 'Veneers', 'Teeth Whitening', 'Root Canal', 'Orthodontics'],
      color: 'from-cyan-500 to-teal-500' 
    },
    { 
      icon: Eye, 
      id: 'ophthalmology',
      name: t('nav.ophthalmology'), 
      desc: locale === 'ar' ? 'جراحة العيون وتصحيح النظر' : locale === 'fa' ? 'جراحی چشم و اصلاح بینایی' : 'Eye surgery and vision correction',
      procedures: ['LASIK', 'Cataract Surgery', 'Glaucoma Treatment', 'Corneal Transplant'],
      color: 'from-purple-500 to-indigo-500' 
    },
    { 
      icon: Brain, 
      id: 'neurology',
      name: locale === 'ar' ? 'جراحة الأعصاب' : locale === 'fa' ? 'جراحی اعصاب' : 'Neurosurgery',
      desc: locale === 'ar' ? 'علاج أمراض الجهاز العصبي' : locale === 'fa' ? 'درمان بیماری‌های سیستم عصبی' : 'Treatment of nervous system disorders',
      procedures: ['Brain Surgery', 'Spine Surgery', 'Tumor Removal'],
      color: 'from-violet-500 to-purple-500' 
    },
    { 
      icon: Baby, 
      id: 'fertility',
      name: locale === 'ar' ? 'علاج العقم' : locale === 'fa' ? 'درمان ناباروری' : 'Fertility Treatment',
      desc: locale === 'ar' ? 'خدمات الإخصاب والحمل' : locale === 'fa' ? 'خدمات باروری و بارداری' : 'IVF and pregnancy services',
      procedures: ['IVF', 'ICSI', 'Egg Freezing', 'Surrogacy'],
      color: 'from-amber-500 to-orange-500' 
    },
    { 
      icon: Scissors, 
      id: 'bariatric',
      name: locale === 'ar' ? 'جراحة السمنة' : locale === 'fa' ? 'جراحی چاقی' : 'Bariatric Surgery',
      desc: locale === 'ar' ? 'جراحات إنقاص الوزن' : locale === 'fa' ? 'جراحی‌های کاهش وزن' : 'Weight loss surgeries',
      procedures: ['Gastric Bypass', 'Sleeve Gastrectomy', 'Gastric Balloon'],
      color: 'from-emerald-500 to-green-500' 
    },
  ]

  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {t('services.title')}
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {t('services.subtitle')}
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <Card key={service.id} className="card-hover overflow-hidden">
              <CardContent className="p-0">
                <div className={`bg-gradient-to-br ${service.color} p-6 text-white`}>
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center">
                      <service.icon className="w-7 h-7" />
                    </div>
                    <h2 className="text-xl font-bold">{service.name}</h2>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-600 mb-4">{service.desc}</p>
                  <div className="mb-4">
                    <h4 className="text-sm font-semibold text-gray-900 mb-2">
                      {locale === 'ar' ? 'الإجراءات الشائعة:' : locale === 'fa' ? 'روش‌های رایج:' : 'Common Procedures:'}
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {service.procedures.slice(0, 4).map((proc, i) => (
                        <span key={i} className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded-full">
                          {proc}
                        </span>
                      ))}
                    </div>
                  </div>
                  <Link href={`/services/${service.id}`}>
                    <Button variant="outline" className="w-full">
                      {t('common.readMore')}
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Card className="bg-gradient-to-r from-[#0099A8] to-[#026D73] text-white">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-4">
                {locale === 'ar' ? 'لست متأكداً من التخصص المناسب؟' : locale === 'fa' ? 'مطمئن نیستید کدام تخصص مناسب است؟' : 'Not Sure Which Specialty?'}
              </h3>
              <p className="mb-6 text-white/90">
                {locale === 'ar' ? 'أرسل لنا استفسارك وسيساعدك فريقنا الطبي' : locale === 'fa' ? 'درخواست خود را ارسال کنید، تیم پزشکی ما کمک خواهد کرد' : 'Submit your inquiry and our medical team will help'}
              </p>
              <Link href="/request">
                <Button size="lg" className="bg-white text-[#0099A8] hover:bg-white/90">
                  {t('hero.cta')}
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
