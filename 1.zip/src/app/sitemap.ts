import { MetadataRoute } from 'next'

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = 'https://iranelaj.com'
  
  const routes = [
    '',
    '/services',
    '/services/cosmetic',
    '/services/cardiology',
    '/services/orthopedics',
    '/services/dentistry',
    '/services/ophthalmology',
    '/doctors',
    '/hospitals',
    '/packages',
    '/hotels',
    '/contact',
    '/about',
    '/blog',
    '/login',
    '/register',
    '/request',
  ]

  return routes.map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: route === '' ? 'daily' : 'weekly',
    priority: route === '' ? 1 : 0.8,
    alternates: {
      languages: {
        ar: `${baseUrl}/ar${route}`,
        fa: `${baseUrl}/fa${route}`,
        en: `${baseUrl}/en${route}`,
      },
    },
  }))
}
