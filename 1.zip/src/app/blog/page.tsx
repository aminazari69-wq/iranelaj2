'use client';

import { useTranslations } from 'next-intl';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

const blogPosts = [
  {
    id: 1,
    slug: 'medical-tourism-iran-guide',
    image: '/images/blog/medical-tourism.jpg',
    category: 'guide',
    date: '2024-01-15',
    titleAr: 'دليل السياحة العلاجية في إيران',
    titleFa: 'راهنمای گردشگری پزشکی در ایران',
    titleEn: 'Medical Tourism Guide to Iran',
    excerptAr: 'كل ما تحتاج معرفته عن السياحة العلاجية في إيران، من اختيار المستشفى إلى ترتيبات السفر.',
    excerptFa: 'همه چیز درباره گردشگری پزشکی در ایران، از انتخاب بیمارستان تا ترتیبات سفر.',
    excerptEn: 'Everything you need to know about medical tourism in Iran, from hospital selection to travel arrangements.',
    readTimeAr: '5 دقائق',
    readTimeFa: '5 دقیقه',
    readTimeEn: '5 min read'
  },
  {
    id: 2,
    slug: 'cosmetic-surgery-benefits',
    image: '/images/blog/cosmetic.jpg',
    category: 'cosmetic',
    date: '2024-01-10',
    titleAr: 'فوائد جراحة التجميل في إيران',
    titleFa: 'مزایای جراحی زیبایی در ایران',
    titleEn: 'Benefits of Cosmetic Surgery in Iran',
    excerptAr: 'اكتشف لماذا يختار آلاف المرضى إيران لعمليات التجميل.',
    excerptFa: 'کشف کنید چرا هزاران بیمار ایران را برای جراحی زیبایی انتخاب می‌کنند.',
    excerptEn: 'Discover why thousands of patients choose Iran for cosmetic procedures.',
    readTimeAr: '4 دقائق',
    readTimeFa: '4 دقیقه',
    readTimeEn: '4 min read'
  },
  {
    id: 3,
    slug: 'cardiac-treatment-iran',
    image: '/images/blog/cardiac.jpg',
    category: 'cardiology',
    date: '2024-01-05',
    titleAr: 'علاج أمراض القلب في إيران',
    titleFa: 'درمان بیماری‌های قلبی در ایران',
    titleEn: 'Cardiac Treatment in Iran',
    excerptAr: 'تعرف على أحدث تقنيات علاج القلب المتوفرة في المستشفيات الإيرانية.',
    excerptFa: 'با جدیدترین تکنیک‌های درمان قلب در بیمارستان‌های ایران آشنا شوید.',
    excerptEn: 'Learn about the latest cardiac treatment technologies available in Iranian hospitals.',
    readTimeAr: '6 دقائق',
    readTimeFa: '6 دقیقه',
    readTimeEn: '6 min read'
  },
  {
    id: 4,
    slug: 'patient-success-stories',
    image: '/images/blog/success.jpg',
    category: 'stories',
    date: '2024-01-01',
    titleAr: 'قصص نجاح المرضى',
    titleFa: 'داستان‌های موفقیت بیماران',
    titleEn: 'Patient Success Stories',
    excerptAr: 'اقرأ قصص حقيقية لمرضى تلقوا علاجهم بنجاح في إيران.',
    excerptFa: 'داستان‌های واقعی بیمارانی که با موفقیت در ایران درمان شدند.',
    excerptEn: 'Read real stories of patients who successfully received treatment in Iran.',
    readTimeAr: '3 دقائق',
    readTimeFa: '3 دقیقه',
    readTimeEn: '3 min read'
  },
  {
    id: 5,
    slug: 'visa-guide-oman',
    image: '/images/blog/visa.jpg',
    category: 'travel',
    date: '2023-12-25',
    titleAr: 'دليل التأشيرة للمسافرين من عُمان',
    titleFa: 'راهنمای ویزا برای مسافران عمانی',
    titleEn: 'Visa Guide for Omani Travelers',
    excerptAr: 'خطوات الحصول على تأشيرة إيران للمواطنين العمانيين.',
    excerptFa: 'مراحل دریافت ویزای ایران برای شهروندان عمانی.',
    excerptEn: 'Steps to obtain an Iran visa for Omani citizens.',
    readTimeAr: '4 دقائق',
    readTimeFa: '4 دقیقه',
    readTimeEn: '4 min read'
  },
  {
    id: 6,
    slug: 'dental-implants-iran',
    image: '/images/blog/dental.jpg',
    category: 'dental',
    date: '2023-12-20',
    titleAr: 'زراعة الأسنان في إيران',
    titleFa: 'ایمپلنت دندان در ایران',
    titleEn: 'Dental Implants in Iran',
    excerptAr: 'لماذا إيران هي الوجهة الأمثل لزراعة الأسنان؟',
    excerptFa: 'چرا ایران بهترین مقصد برای ایمپلنت دندان است؟',
    excerptEn: 'Why Iran is the ideal destination for dental implants?',
    readTimeAr: '5 دقائق',
    readTimeFa: '5 دقیقه',
    readTimeEn: '5 min read'
  }
];

const categories = [
  { id: 'all', labelAr: 'الكل', labelFa: 'همه', labelEn: 'All' },
  { id: 'guide', labelAr: 'أدلة', labelFa: 'راهنما', labelEn: 'Guides' },
  { id: 'cosmetic', labelAr: 'تجميل', labelFa: 'زیبایی', labelEn: 'Cosmetic' },
  { id: 'cardiology', labelAr: 'قلب', labelFa: 'قلب', labelEn: 'Cardiology' },
  { id: 'stories', labelAr: 'قصص', labelFa: 'داستان', labelEn: 'Stories' },
  { id: 'travel', labelAr: 'سفر', labelFa: 'سفر', labelEn: 'Travel' },
  { id: 'dental', labelAr: 'أسنان', labelFa: 'دندان', labelEn: 'Dental' }
];

export default function BlogPage() {
  const t = useTranslations('common');
  
  return (
    <div className="min-h-screen bg-[#F8FDFD]">
      {/* Hero */}
      <section className="bg-gradient-to-br from-[#0099A8] to-[#026D73] text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            المدونة الطبية
          </h1>
          <p className="text-xl opacity-90 max-w-2xl mx-auto">
            أحدث المقالات والأخبار حول السياحة العلاجية في إيران
          </p>
        </div>
      </section>

      {/* Categories */}
      <section className="py-8 border-b bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap gap-2 justify-center">
            {categories.map((cat) => (
              <Button
                key={cat.id}
                variant={cat.id === 'all' ? 'default' : 'outline'}
                size="sm"
                className="rounded-full"
              >
                {cat.labelAr}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <Card key={post.id} className="overflow-hidden hover:shadow-xl transition-shadow group">
                <div className="relative h-48 bg-gradient-to-br from-[#0099A8]/20 to-[#026D73]/20">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <svg className="w-16 h-16 text-[#0099A8]/40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                    </svg>
                  </div>
                  <Badge className="absolute top-3 start-3 bg-[#0099A8]">
                    {categories.find(c => c.id === post.category)?.labelAr}
                  </Badge>
                </div>
                <CardHeader>
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                    <span>{new Date(post.date).toLocaleDateString('ar-SA')}</span>
                    <span>•</span>
                    <span>{post.readTimeAr}</span>
                  </div>
                  <CardTitle className="text-lg group-hover:text-[#0099A8] transition-colors line-clamp-2">
                    {post.titleAr}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-sm line-clamp-3 mb-4">
                    {post.excerptAr}
                  </p>
                  <Link 
                    href={`/blog/${post.slug}`}
                    className="text-[#0099A8] font-medium hover:text-[#026D73] transition-colors inline-flex items-center gap-1"
                  >
                    اقرأ المزيد
                    <svg className="w-4 h-4 rtl:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Load More */}
          <div className="text-center mt-12">
            <Button variant="outline" size="lg">
              تحميل المزيد من المقالات
            </Button>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-[#0099A8]">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            اشترك في النشرة الإخبارية
          </h2>
          <p className="text-white/90 mb-8 max-w-xl mx-auto">
            احصل على آخر المقالات والعروض مباشرة إلى بريدك الإلكتروني
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="البريد الإلكتروني"
              className="flex-1 px-4 py-3 rounded-lg border-0 focus:ring-2 focus:ring-white"
            />
            <Button className="bg-[#026D73] hover:bg-[#015A5F] text-white px-8">
              اشترك
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
